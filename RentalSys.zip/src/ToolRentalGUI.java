import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class ToolRentalGUI extends JFrame {
    private List<Tool> toolInventory;
    private JComboBox<Tool> toolComboBox;
    private JTextArea displayArea;

    public ToolRentalGUI() {
        toolInventory = new ArrayList<>();
        
        // Populate initial tool inventory
        toolInventory.add(new Tool("Hammer", "Used for driving nails"));
        toolInventory.add(new Tool("Screwdriver", "Used for tightening screws"));
        toolInventory.add(new Tool("Wrench", "Used for tightening nuts and bolts"));

        setTitle("Tool Rental System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
        JLabel toolLabel = new JLabel("Tool:");
        toolComboBox = new JComboBox<>(toolInventory.toArray(new Tool[0]));
        JButton rentButton = new JButton("Rent");
        rentButton.addActionListener(new RentButtonListener());

        inputPanel.add(toolLabel);
        inputPanel.add(toolComboBox);
        inputPanel.add(rentButton);

        displayArea = new JTextArea();
        displayArea.setEditable(false);

        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(displayArea), BorderLayout.CENTER);
    }

    private class RentButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Tool selectedTool = (Tool) toolComboBox.getSelectedItem();
            if (selectedTool != null) {
                selectedTool.setRented(true);
                displayArea.append("Rented: " + selectedTool.getName() + "\n");
            }
        }
    }

    private class Tool {
        private String name;
        private String description;
        private boolean isRented;

        public Tool(String name, String description) {
            this.name = name;
            this.description = description;
            this.isRented = false;
        }

        public String getName() {
            return name;
        }

        public boolean isRented() {
            return isRented;
        }

        public void setRented(boolean rented) {
            isRented = rented;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ToolRentalGUI gui = new ToolRentalGUI();
            gui.setVisible(true);
        });
    }
}